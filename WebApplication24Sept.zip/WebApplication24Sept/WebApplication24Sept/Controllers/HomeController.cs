﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication24Sept.Models;

namespace WebApplication24Sept.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
           
           // string name;
            //return Json(new { id = 1, name = "Swati" });
            if (TempData.ContainsKey("name"))
            {
                //Employee e = TempData["emp"] as Employee;
                ViewBag.name = TempData["name"];
                TempData.Keep();
                
            }
            return View();
        }
        public IActionResult ShowEmployeeDetails()
        {
            Employee e = new Employee() { id = 123, ename = "Sunita" };
            ViewData["emp"] = e;
            ViewBag.emp = e;
            TempData["name"] = "Swati";
            return RedirectToAction("Index");
        }


    }
}