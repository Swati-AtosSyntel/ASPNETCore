﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AuthenticationDemo.Controllers
{
    [Authorize]
    public class EmployeeController : Controller
    {
        [AllowAnonymous]
        public IActionResult Index()
        {
            return View();
        }        
        public IActionResult Create()
        {
            return View();
        }
    }
}