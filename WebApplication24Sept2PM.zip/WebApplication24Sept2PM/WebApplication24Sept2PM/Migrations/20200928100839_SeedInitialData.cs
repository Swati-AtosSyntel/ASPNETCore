﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication24Sept2PM.Migrations
{
    public partial class SeedInitialData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "employees",
                columns: new[] { "eid", "dept", "emailid", "ename" },
                values: new object[] { 1, "Manufacturing", "Swati1.Bhirud@gmail.com", "Swati" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "employees",
                keyColumn: "eid",
                keyValue: 1);
        }
    }
}
