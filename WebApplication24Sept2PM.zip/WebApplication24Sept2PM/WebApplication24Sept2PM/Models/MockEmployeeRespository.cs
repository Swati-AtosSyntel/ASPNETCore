﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication24Sept2PM.Models
{
    public class MockEmployeeRespository : IEmployeeRepository
    {
        List<Employee> employees = new List<Employee>()
        {
            new Employee(){eid=1,ename="Swati",emailid="swati1.bhirud@gmail.com",dept="Training" },
            new Employee(){eid=2,ename="Sonali",emailid="sonali@gmail.com",dept="HR" }
        };
        public void AddNewEmployee(Employee e)
        {
            employees.Add(e);
        }

        public void DeleteEmployee(int id)
        {
         
        }

        public List<Employee> GetAllEmployees()
        {
            return employees;
        }

        public Employee SearchEmployee(int id)
        {
            Employee e = employees.Find(emp => emp.eid == id);
            return e;
        }

        public void UpdateEmployeeinfo(Employee newEmployee)
        {
            
        }
    }
}
