﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication24Sept2PM.Models
{
    public class SQLEmployeeRepository : IEmployeeRepository
    {
        public SQLEmployeeRepository(AppDBContext context)
        {
            Context = context;
        }

        public AppDBContext Context { get; }

        public void AddNewEmployee(Employee e)
        {
            Context.Add(e);
            Context.SaveChanges();

        }

        public void DeleteEmployee(int id)
        {
            Employee e = Context.employees.Find(id);
            if(e!=null)
            {
                Context.employees.Remove(e);
                Context.SaveChanges();
            }
        }

        public List<Employee> GetAllEmployees()
        {
            return Context.employees.ToList();

        }

        public Employee SearchEmployee(int id)
        {
            return Context.employees.Find(id);
        }

        public void UpdateEmployeeinfo(Employee newEmployee)
        {
            var employee = Context.employees.Attach(newEmployee);
            employee.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            Context.SaveChanges();
        }
    }
}
