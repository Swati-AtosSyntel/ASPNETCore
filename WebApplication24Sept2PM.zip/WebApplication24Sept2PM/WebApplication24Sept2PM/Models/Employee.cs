﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication24Sept2PM.Models
{
    public class Employee
    {
        [Required(ErrorMessage ="Enter Employee ID")]
        [Display(Name ="Employee ID")]
        [Key]
        public int eid { get; set; }
        [Required(ErrorMessage = "Enter Employee Name")]
        [Display(Name = "Employee Name")]
        public string ename { get; set; }
        [Required(ErrorMessage = "Enter Email Address")]
        [EmailAddress(ErrorMessage ="Enter valid Email Address")]
        [Display(Name = "Email ID")]
        public string emailid { get; set; }
        [Required(ErrorMessage = "Enter Department")]
        [Display(Name = "Department")]
        public string dept { get; set; }

        public string location { get; set; }
    }
}
