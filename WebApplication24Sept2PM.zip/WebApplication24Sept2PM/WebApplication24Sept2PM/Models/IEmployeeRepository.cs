﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication24Sept2PM.Models
{
    public interface IEmployeeRepository
    {
        void AddNewEmployee(Employee e);
        Employee SearchEmployee(int id);
        List<Employee> GetAllEmployees();
        void UpdateEmployeeinfo(Employee newEmployee);

        void DeleteEmployee(int id);

    }
}
