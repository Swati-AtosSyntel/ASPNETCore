﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication24Sept2PM.Models;

namespace WebApplication24Sept2PM.ViewComponents
{
    public class EmployeeListViewComponent:ViewComponent
    {
        public async Task<IViewComponentResult> InvokeAsync(int n)
        {
            List<Employee> empList = new List<Employee>();
            for(int i=0;i<n;i++)
            {
                empList.Add(new Employee { eid = i, ename = "Emp" + i });
               
            }
            return View("EmployeeList", empList);
        }
    }
}
