﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication24Sept2PM.Models;

namespace WebApplication24Sept2PM.Controllers
{
    public class EmployeeController : Controller
    {
        IEmployeeRepository employeeRepository;
        public EmployeeController(IEmployeeRepository employeeRepository)
        {
            this.employeeRepository = employeeRepository;
        }
        public IActionResult Index()
        {
            return View(employeeRepository.GetAllEmployees());
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employee e)
        {
            if (ModelState.IsValid)
            {
                employeeRepository.AddNewEmployee(e);
                return View("Index",employeeRepository.GetAllEmployees());
            }
            return View();
        }
        public IActionResult Details(int id)
        {
            return View(employeeRepository.SearchEmployee(id));
        }
    }
}