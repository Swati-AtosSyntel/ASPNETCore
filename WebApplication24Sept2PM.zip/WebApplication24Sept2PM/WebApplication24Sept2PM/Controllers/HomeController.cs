﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace WebApplication24Sept2PM.Controllers
{
    public class HomeController : Controller
    {
        public HomeController(ILoggerFactory loggerFactory)
        {
            this.logger = loggerFactory.CreateLogger<HomeController>();
        }

        public ILogger logger { get; }

        public IActionResult Index()
        {
            TempData["name"] = "Swati";

            return View("Index3");
        }
        public IActionResult Index1()
        {
            //string name;
            if (TempData.ContainsKey("name"))
            {
                ViewBag.name = TempData["name"] as string;
                TempData.Keep();
            }


            return View();
        }
        public IActionResult Index2()
        {
            logger.LogInformation("This msg is coming from Home Controller Index2 action method");
            logger.LogError("There is some error");
            return ViewComponent("EmployeeList",new { n = 5 });
        }
    }
}