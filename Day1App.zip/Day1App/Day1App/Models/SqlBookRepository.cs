﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Day1App.Models
{
    public class SqlBookRepository : BooksRepository
    {
        public SqlBookRepository(AppDbContext context)
        {
            Context = context;
        }

        public AppDbContext Context { get; }

        public void AddNewBook(Book b)
        {
            Context.Books.Add(b);
            Context.SaveChanges();
        }

        public void DeleteBook(int id)
        {
           
        }

        public List<Book> GetBooks()
        {
            return Context.Books.ToList();
        }

        public Book SearchBook(int id)
        {
            return Context.Books.SingleOrDefault(b => b.BookID == id);
        }

        public void UpdateBook(Book UpdatedBook)
        {
           
        }
    }
}
