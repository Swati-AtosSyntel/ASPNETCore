﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Day1App.Models
{
    public class MockRepository : BooksRepository
    {
        List<Book> books = new List<Book>()
        {
            new Book(){
                BookID=123,
                BookName="Azure Fundamentals",
                price=678,
                AuthorID=555,
                AuthorName="Smith",
                EmailID="Smith@gmail.com"
            }
        };
        public void AddNewBook(Book b)
        {
            books.Add(b);
        }

        public void DeleteBook(int id)
        {
            Book b = books.SingleOrDefault(b1 => b1.BookID == id);
            books.Remove(b);
        }

        public List<Book> GetBooks()
        {
            return books;
        }

        public Book SearchBook(int id)
        {
           return books.SingleOrDefault(b1 => b1.BookID == id);
        }

        public void UpdateBook(Book UpdatedBook)
        {
           
        }
    }
}
