﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Day1App.Models
{
   public interface BooksRepository
    {
        List<Book> GetBooks();
        Book SearchBook(int id);
        void AddNewBook(Book b);
        void DeleteBook(int id);
        void UpdateBook(Book UpdatedBook);
        
    }
}
