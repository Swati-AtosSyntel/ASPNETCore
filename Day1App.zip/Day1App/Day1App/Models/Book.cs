﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Day1App.Models
{
    public class Book
    {
        [Required(ErrorMessage ="Enter Book ID")]
        public int BookID { get; set; }
        [Required(ErrorMessage = "Enter Book Name")]
        public string BookName { get; set; }

        public string Description { get; set; }
        [Required(ErrorMessage = "Enter Price")]
        public int price { get; set; }
        [Required(ErrorMessage = "Enter Author ID")]
        public int AuthorID { get; set; }
        [Required(ErrorMessage = "Enter Author Name")]
        public string AuthorName { get; set; }
        [Required(ErrorMessage = "Enter Email ID")]
        [EmailAddress(ErrorMessage ="Invalid Email Address")]
        public string EmailID { get; set; }
        [ScaffoldColumn(false)]
        public string zipcode { get; set; }
    }
}
