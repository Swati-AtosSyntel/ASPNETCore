﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Day1App.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;

namespace Day1App
{
    public class Startup
    {
        public IConfiguration Config { get; }

        public Startup(IConfiguration Config)
        {
            this.Config = Config;
        }
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContextPool<AppDbContext>(options=>options.UseSqlServer(Config.GetConnectionString("DefaultConnection")));
            services.AddScoped<BooksRepository, SqlBookRepository>();
            services.AddMvc();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else if(env.IsProduction()|| env.IsStaging())
            {
                app.UseExceptionHandler("");
            }
            //app.UseDefaultFiles();//changes the request path to default page
            //app.UseStaticFiles();//processes the static files under wwwroot
            //app.UseStaticFiles(new StaticFileOptions
            //{
            //    FileProvider = new PhysicalFileProvider(
            //Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "StaticPages"))
            //});
            //UseFileServer combines functionality of 3 middlewears
            FileServerOptions defaultFileOption = new FileServerOptions();
            defaultFileOption.DefaultFilesOptions.DefaultFileNames.Clear();
            defaultFileOption.DefaultFilesOptions.DefaultFileNames.Add("Home.html");

            app.UseFileServer(defaultFileOption);
            app.UseFileServer(new FileServerOptions
            {
              FileProvider = new PhysicalFileProvider(
              Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "StaticPages"))
            });
            //app.Use(async (context,next) =>
            //{
            //    //throw new Exception("Something went wrong!!!!!");
            //    await context.Response.WriteAsync("Hello World! from first Middlewear \n");
            //    await next();
            //});
            app.UseMvcWithDefaultRoute();
           

        }
    }
}
