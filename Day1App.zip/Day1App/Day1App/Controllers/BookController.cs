﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Day1App.Models;
using Microsoft.AspNetCore.Mvc;

namespace Day1App.Controllers
{
    public class BookController : Controller
    {
        public BookController(BooksRepository booksRepository)
        {
            BooksRepository = booksRepository;
        }

        public BooksRepository BooksRepository { get; }

        public IActionResult Index()
        {
            return View(BooksRepository.GetBooks());
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Book b)
        {
            if(ModelState.IsValid)
            {
                BooksRepository.AddNewBook(b);
                return View("Index", BooksRepository.GetBooks());
            }
            return View();
        }
    }
}