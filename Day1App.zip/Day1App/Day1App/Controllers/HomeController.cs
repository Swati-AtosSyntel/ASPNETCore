﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Day1App.Models;
using Microsoft.AspNetCore.Mvc;

namespace Day1App.Controllers
{
    public class HomeController : Controller
    {
        public BooksRepository BooksRepository { get; }
        public HomeController(BooksRepository booksRepository)
        {
            BooksRepository = booksRepository;
        }

        public IActionResult Index1()
        {
            return ViewComponent("EmployeeList");
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ShowBooks()
        {
            return View(BooksRepository.GetBooks());
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Book b)
        {
            if (ModelState.IsValid)
            {
                BooksRepository.AddNewBook(b);
                return View("Index", BooksRepository.GetBooks());
            }
            return View();
        }
    }
}