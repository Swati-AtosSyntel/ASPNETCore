﻿using Day1App.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Day1App.ViewComponents
{
    public class EmployeeList:ViewComponent
    {
        public EmployeeList()
        {
            
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {

            List<Book> books = new List<Book>()
            {
                new Book(){BookID=100,BookName="C Programming"},
                new Book(){BookID=101,BookName="C++ Programming"},
                new Book(){BookID=102,BookName="C# Programming"},
                new Book(){BookID=103,BookName="ASP.NET MVC"},
                new Book(){BookID=104,BookName="ASP.NET Core"},
                new Book(){BookID=105,BookName="Azure Fundamentals"},
            };
            return View("EmployeeList",books);
        }
    }
}
