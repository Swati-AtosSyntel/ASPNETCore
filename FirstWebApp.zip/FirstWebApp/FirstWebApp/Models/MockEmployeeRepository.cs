﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstWebApp.Models
{
    public class MockEmployeeRepository : IEmployeeRepository
    {
        List<Employee> employees = new List<Employee>()
        {
            new Employee(){eid=1,ename="Swati",location="Pune",email="swati1.bhirud@gmail.com",DOJ="15/02/2015" },
            new Employee(){eid=2,ename="Ankit",location="Pune",email="Ankit@gmail.com",DOJ="15/02/2016" },
            new Employee(){eid=3,ename="Ashish",location="Mumbai",email="Ashish@gmail.com",DOJ="18/8/2015" },
            new Employee(){eid=4,ename="Nikita",location="Chennai",email="nikita@gmail.com",DOJ="15/02/2015" }
        };
        public void AddNewEmployee(Employee e)
        {
            employees.Add(e);
        }

        public void DeleteEmployee(int id)
        {
            Employee e = employees.SingleOrDefault(emp => emp.eid == id);
            if(e!=null)
            {
                employees.Remove(e);
            }
        }

        public Employee GetEmployee(int id)
        {
            return employees.SingleOrDefault(emp => emp.eid == id);
        }

       

        public List<Employee> GetEmployees()
        {
            return employees;
        }

        public void UpdateEmployee(Employee newEmployee)
        {
           
        }
    }
}
