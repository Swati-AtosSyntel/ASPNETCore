﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FirstWebApp.Models
{
    public class Employee
    {
        [Required]
        [Key]
        [Display(Name ="Employee ID")]
        public int eid { get; set; }
        [Required]
        [Display(Name = "Employee Name")]
        public string ename { get; set; }
        [Required]
        [Display(Name = "WorkLocation")]
        public string location { get; set; }
        [Required]
        [Display(Name = "Email Address")]
        [EmailAddress]
        public string email { get; set;}
        [Required]
        [Display(Name = "Date Of Joining")]
        [DataType(DataType.Date)]
        public string DOJ { get; set; }
        [ScaffoldColumn(false)]
        
       
        public int zipCode { get; set; }
    }
}
