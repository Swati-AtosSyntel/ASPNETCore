﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstWebApp.Models
{
    public class SqlEmployeeRepository : IEmployeeRepository
    {
        public SqlEmployeeRepository(AppDbContext context)
        {
            Context = context;
        }

        public AppDbContext Context { get; }

        public void AddNewEmployee(Employee e)
        {
            Context.employees.Add(e);
            Context.SaveChanges();
        }

        public void DeleteEmployee(int id)
        {
            Employee e = Context.employees.SingleOrDefault(emp => emp.eid == id);
            if(e!=null)
            {
                Context.employees.Remove(e);
                Context.SaveChanges();
            }
        }

        public Employee GetEmployee(int id)
        {
           return Context.employees.SingleOrDefault(emp => emp.eid == id);
        }

        public List<Employee> GetEmployees()
        {
            return Context.employees.ToList();
        }

        public void UpdateEmployee(Employee newEmployee)
        {
            var employee = Context.employees.Attach(newEmployee);
            employee.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            Context.SaveChanges();
        }
    }
}
