﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FirstWebApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace FirstWebApp.Controllers
{
    public class HomeController : Controller
    {
        public HomeController(IEmployeeRepository employeeRepository)
        {
            EmployeeRepository = employeeRepository;
        }

        public IEmployeeRepository EmployeeRepository { get; }

        public IActionResult Index()
        {
            return ViewComponent("EmployeeList", new { n = 5 });
        }
        public JsonResult ShowData()
        {
            return Json(new { id = 1, name = "Swati" });
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employee e)
        {
            if(ModelState.IsValid)
            {
                EmployeeRepository.GetEmployees().Add(e);
                return View("ShowEmployees", EmployeeRepository.GetEmployees());
            }
            return View();
        }
        [HttpPost]
        public IActionResult Details(int id)
        {

            return View(EmployeeRepository.GetEmployee(id));
        }
        public IActionResult ShowEmployees()
        {
            return View(EmployeeRepository.GetEmployees());
        }
        
    }
}