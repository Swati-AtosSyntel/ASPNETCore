﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FirstWebApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace FirstWebApp.Controllers
{
    public class EmployeeController : Controller
    {
        IEmployeeRepository employeeRepository;

        public ILogger Logger { get; }

        public EmployeeController(IEmployeeRepository employeeRepository,ILoggerFactory logger)
        {
            this.employeeRepository = employeeRepository;
            Logger = logger.CreateLogger<EmployeeController>();
        }
        // GET: Employee
        public ActionResult Index()
        {
            Logger.LogInformation("Log message coming from EmployeeController Index Action Method");
            return View(employeeRepository.GetEmployees());
        }

        // GET: Employee/Details/5
        public ActionResult Details(int id)
        {
            employeeRepository.GetEmployee(id);
            return View();
        }

        // GET: Employee/Create
        public ActionResult Create()
        {

            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee e)
        {
              if (ModelState.IsValid)
                {
                    employeeRepository.AddNewEmployee(e);
                    return RedirectToAction("Index");
                }
           
            return View();
        }

        // GET: Employee/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Employee/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id,Employee e)
        {
            try
            {
                // TODO: Add update logic here
                employeeRepository.UpdateEmployee(e);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Employee/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}