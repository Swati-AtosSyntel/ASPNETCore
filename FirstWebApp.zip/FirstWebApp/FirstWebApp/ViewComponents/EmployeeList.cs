﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstWebApp.ViewComponents
{
    public class EmployeeList:ViewComponent
    {
        public async Task<IViewComponentResult> InvokeAsync(int n)
        {
            List<Models.Employee> list = new List<Models.Employee>();
            int count = 1;
            while(count<=n)
            {
                list.Add(new Models.Employee() { eid = count, ename = "Employee" + count });
            }
            return View("EmployeeList", list);

        }
    }
}
