﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.ViewComponents
{
    public class EmployeeListViewComponent:ViewComponent
    {
        public async Task<IViewComponentResult> InvokeAsync(int n)
        {
            List<Employee> emps = new List<Employee>();

            for(var i=0;i<n;i++)
            {
                emps.Add(new Employee { eid = i, ename = "Emp" + i });

            }
            return View("EmployeeList",emps);
        }
    }
}
