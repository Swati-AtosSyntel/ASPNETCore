﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
       
        public HomeController(IEmployeeRepository employeeRepository,ILogger<HomeController> Logger)
        {
            EmployeeRepository = employeeRepository;
            this.Logger = Logger;
        }

        public IEmployeeRepository EmployeeRepository { get; }
        public ILogger<HomeController> Logger { get; }

        public IActionResult Index()
        {
            Logger.LogInformation("This message is from Home Controller IndexAction Method");
            return View(EmployeeRepository.GetEmployees());
        }
        [HttpGet]
        public IActionResult Create()
        {
            Logger.LogError("This message is from Home Controller Create Action Method");
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employee e)
        {
            if(ModelState.IsValid)
            {
                EmployeeRepository.AddNewEmployee(e);
                return View("Index", EmployeeRepository.GetEmployees());
            }
            return View();
        }
        public IActionResult Index1()
        {
            return ViewComponent("EmployeeList", new { n = 3 });
        }
    }
}