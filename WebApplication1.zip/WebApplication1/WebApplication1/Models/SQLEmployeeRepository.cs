﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//namespace WebApplication1.Models
//{
//    public class SQLEmployeeRepository : IEmployeeRepository
//    {
//        public void AddNewEmployee(Employee e)
//        {
            
//        }

//        public void DeleteEmployee(int id)
//        {
            
//        }

//        public Employee GetEmployee(int id)
//        {
//            return new Employee();
//        }

//        public List<Employee> GetEmployees()
//        {
//            return 
//        }

//        public Employee UpdateEmployee(Employee newEmployee)
//        {
            
//        }
//    }
//}
