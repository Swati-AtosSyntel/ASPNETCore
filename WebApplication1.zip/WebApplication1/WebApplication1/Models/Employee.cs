﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Employee
    {
        [Required]
        [Display(Name ="Employee ID")]
        public int eid { get; set; }
        [Required]
        [Display(Name = "Employee Name")]
        public string ename { get; set; }
        [Required]
        [Display(Name = "Email Address")]
        [DataType(DataType.EmailAddress)]
        public string emailId { get; set; }
        [Required]
        [Display(Name = "Department")]
        public string dept { get; set; }
    }
}
