﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
   public interface IEmployeeRepository
    {
        void AddNewEmployee(Employee e);

        Employee GetEmployee(int id);
        List<Employee> GetEmployees();

        Employee UpdateEmployee(Employee newEmployee);
        void DeleteEmployee(int id);

    }
}
