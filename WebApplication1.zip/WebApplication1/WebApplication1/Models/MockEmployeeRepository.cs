﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class MockEmployeeRepository : IEmployeeRepository
    {
        List<Employee> employees = new List<Employee>();
        public void AddNewEmployee(Employee e)
        {
            employees.Add(e);

        }

        public void DeleteEmployee(int id)
        {
            Employee e = employees.SingleOrDefault(emp=>emp.eid==id);
            employees.Remove(e);
        }

        public Employee GetEmployee(int id)
        {
            Employee e = employees.SingleOrDefault(emp => emp.eid == id);
            return e;
        }

        public List<Employee> GetEmployees()
        {
            return employees;
        }

        public Employee UpdateEmployee(Employee newEmployee)
        {
            Employee e = employees.SingleOrDefault(emp => emp.eid == newEmployee.eid);
            e = newEmployee;
            return e;
        }
    }
}
